.text
main:
    lui x2, 0x10000

loop:
    addi x1, x0, 1
    sw x1, 0(x2)

    addi x3, x0, 100
delay1:
    addi x3, x3, -1
    bne x3, x0, delay1

    addi x1, x0, 0
    sw x1, 0(x2)

    addi x3, x0, 100
delay2:
    addi x3, x3, -1
    bne x3, x0, delay2

    bne x2, x0, loop
.end
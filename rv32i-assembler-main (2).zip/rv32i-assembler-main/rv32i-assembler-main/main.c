#include "assembler.h"
#include "object_writer.h"

int main() {
    //run_assembler("input.asm");
    //write_object_file("program1.o", "input.asm");

    run_assembler("input2.asm");
    write_object_file("program2.o", "input2.asm");
    return 0;
}
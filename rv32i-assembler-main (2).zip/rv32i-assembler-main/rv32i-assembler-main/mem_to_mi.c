#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define IMEM_DEPTH 1024

void write_binary32(FILE *out, uint32_t value) {
    for (int i = 31; i >= 0; i--) {
        fputc((value & (1u << i)) ? '1' : '0', out);
    }
    fputc('\n', out);
}

int main() {
    FILE *in = fopen("linked.mem", "r");
    FILE *out = fopen("linked.mi", "w");

    char line[128];
    int count = 0;

    if (!in) {
        printf("linked.mem not found!\n");
        return 1;
    }

    if (!out) {
        printf("linked.mi could not be created!\n");
        fclose(in);
        return 1;
    }

    fprintf(out, "#File_format=Bin\n");
    fprintf(out, "#Address_depth=1024\n");
    fprintf(out, "#Data_width=32\n");

    while (fgets(line, sizeof(line), in)) {
        line[strcspn(line, "\r\n")] = 0;

        if (strlen(line) == 0) continue;

        uint32_t instr = (uint32_t)strtoul(line, NULL, 16);
        write_binary32(out, instr);
        count++;
    }

    while (count < IMEM_DEPTH) {
        write_binary32(out, 0x00000013);
        count++;
    }

    fclose(in);
    fclose(out);

    printf("linked.mi generated successfully. Depth = %d words\n", IMEM_DEPTH);
    return 0;
}
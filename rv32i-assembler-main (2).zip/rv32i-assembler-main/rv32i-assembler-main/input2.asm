.text
func:
addi x3, x0, 1
addi x4, x0, 2
bne x3, x4, func
.end
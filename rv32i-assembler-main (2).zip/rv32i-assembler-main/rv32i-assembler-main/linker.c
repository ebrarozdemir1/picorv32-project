#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE 256
#define MAX_SYMBOLS 256
#define MAX_RELOCS 256

typedef struct {
    char name[50];
    char section[20];
    unsigned int local_address;
    unsigned int final_address;
    char object_file[100];
} GlobalSymbol;

typedef struct {
    unsigned int address;
    char mnemonic[20];
    char label[50];
    char object_file[100];
} RelocEntry;

GlobalSymbol global_symbols[MAX_SYMBOLS];
int global_symbol_count = 0;

RelocEntry reloc_table[MAX_RELOCS];
int reloc_count = 0;

int get_text_size(const char *object_file) {
    FILE *in = fopen(object_file, "r");
    char line[MAX_LINE];
    int in_text = 0;
    int count = 0;

    if (!in) return 0;

    while (fgets(line, sizeof(line), in)) {
        line[strcspn(line, "\r\n")] = 0;

        if (strcmp(line, "SECTION .text") == 0) {
            in_text = 1;
            continue;
        }

        if (strcmp(line, "SECTION .data") == 0) {
            in_text = 0;
            continue;
        }

        if (strncmp(line, "SYMBOL", 6) == 0) continue;
        if (strncmp(line, "RELOC", 5) == 0) continue;
        if (strcmp(line, "END") == 0) break;

        if (in_text && strlen(line) > 0) {
            count++;
        }
    }

    fclose(in);
    return count * 4;
}

void collect_symbols(const char *object_file, unsigned int text_base) {
    FILE *in = fopen(object_file, "r");
    char line[MAX_LINE];

    if (!in) {
        printf("Cannot open object file: %s\n", object_file);
        return;
    }

    while (fgets(line, sizeof(line), in)) {
        char type[20], name[50], scope[20], section[20];
        unsigned int addr;

        if (sscanf(line, "%s %s %s %s %u", type, name, scope, section, &addr) == 5) {
            if (strcmp(type, "SYMBOL") == 0) {
                strcpy(global_symbols[global_symbol_count].name, name);
                strcpy(global_symbols[global_symbol_count].section, section);
                strcpy(global_symbols[global_symbol_count].object_file, object_file);
                global_symbols[global_symbol_count].local_address = addr;
                global_symbols[global_symbol_count].final_address = text_base + addr;
                global_symbol_count++;
            }
        }
    }

    fclose(in);
}

void collect_relocations(const char *object_file, unsigned int text_base) {
    FILE *in = fopen(object_file, "r");
    char line[MAX_LINE];

    if (!in) {
        printf("Cannot open object file: %s\n", object_file);
        return;
    }

    while (fgets(line, sizeof(line), in)) {
        char type[20], section[20], mnemonic[20], label[50];
        unsigned int addr;

        if (sscanf(line, "%s %s %u %s %s", type, section, &addr, mnemonic, label) == 5) {
            if (strcmp(type, "RELOC") == 0) {
                reloc_table[reloc_count].address = text_base + addr;
                strcpy(reloc_table[reloc_count].mnemonic, mnemonic);
                strcpy(reloc_table[reloc_count].label, label);
                strcpy(reloc_table[reloc_count].object_file, object_file);
                reloc_count++;
            }
        }
    }

    fclose(in);
}

unsigned int find_symbol_final(const char *name, const char *object_file) {
    for (int i = 0; i < global_symbol_count; i++) {
        if (strcmp(global_symbols[i].name, name) == 0 &&
            strcmp(global_symbols[i].object_file, object_file) == 0) {
            return global_symbols[i].final_address;
        }
    }

    for (int i = 0; i < global_symbol_count; i++) {
        if (strcmp(global_symbols[i].name, name) == 0) {
            return global_symbols[i].final_address;
        }
    }

    printf("Undefined symbol: %s\n", name);
    return 0;
}

void append_text_section(FILE *out, const char *object_file) {
    FILE *in = fopen(object_file, "r");
    char line[MAX_LINE];
    int in_text = 0;

    if (!in) {
        printf("Cannot open object file: %s\n", object_file);
        return;
    }

    printf("Linking: %s\n", object_file);

    while (fgets(line, sizeof(line), in)) {
        line[strcspn(line, "\r\n")] = 0;

        if (strcmp(line, "SECTION .text") == 0) {
            in_text = 1;
            continue;
        }

        if (strcmp(line, "SECTION .data") == 0) {
            in_text = 0;
            continue;
        }

        if (strncmp(line, "SYMBOL", 6) == 0) continue;
        if (strncmp(line, "RELOC", 5) == 0) continue;
        if (strcmp(line, "END") == 0) break;

        if (in_text && strlen(line) > 0) {
            fprintf(out, "%s\n", line);
        }
    }

    fclose(in);
}

void apply_relocations(const char *filename) {
    FILE *file = fopen(filename, "r+");
    char lines[2048][50];
    int line_count = 0;

    if (!file) {
        printf("Cannot open linked file for relocation!\n");
        return;
    }

    while (fgets(lines[line_count], sizeof(lines[0]), file)) {
        line_count++;
    }

    for (int i = 0; i < reloc_count; i++) {
        unsigned int instr_index = reloc_table[i].address / 4;

        unsigned int target = find_symbol_final(
            reloc_table[i].label,
            reloc_table[i].object_file
        );

        unsigned int current = reloc_table[i].address;
        int offset = (int)target - (int)current;

        printf("RELOC: addr=%u object=%s mnemonic=%s label=%s target=%u offset=%d\n",
               current,
               reloc_table[i].object_file,
               reloc_table[i].mnemonic,
               reloc_table[i].label,
               target,
               offset);

        if (instr_index >= (unsigned int)line_count) {
            printf("Relocation address out of range!\n");
            continue;
        }

        unsigned int original_instr;
        sscanf(lines[instr_index], "%x", &original_instr);

        unsigned int imm = offset & 0x1FFF;

        unsigned int imm12   = (imm >> 12) & 0x1;
        unsigned int imm11   = (imm >> 11) & 0x1;
        unsigned int imm10_5 = (imm >> 5)  & 0x3F;
        unsigned int imm4_1  = (imm >> 1)  & 0xF;

        unsigned int clear_mask = 0xFE000F80;

        unsigned int new_instr = original_instr & ~clear_mask;

        new_instr |= (imm12   << 31);
        new_instr |= (imm10_5 << 25);
        new_instr |= (imm4_1  << 8);
        new_instr |= (imm11   << 7);

        sprintf(lines[instr_index], "%08x\n", new_instr);
    }

    rewind(file);

    for (int i = 0; i < line_count; i++) {
        fputs(lines[i], file);
    }

    fclose(file);

    printf("Relocation applied with real B-type encoding.\n");
}

void write_symbol_map(const char *filename) {
    FILE *out = fopen(filename, "w");

    if (!out) {
        printf("Cannot create ESTAB file!\n");
        return;
    }

    fprintf(out, "ESTAB - EXTERNAL SYMBOL TABLE\n");
    fprintf(out, "-----------------------------\n");

    for (int i = 0; i < global_symbol_count; i++) {
        fprintf(out, "%s %s local=%u final=%u object=%s\n",
                global_symbols[i].name,
                global_symbols[i].section,
                global_symbols[i].local_address,
                global_symbols[i].final_address,
                global_symbols[i].object_file);
    }

    fclose(out);

    printf("ESTAB generated: %s\n", filename);
}

void link_multiple_objects(const char *output_file, const char *objects[], int object_count) {
    FILE *out = fopen(output_file, "w");
    unsigned int text_base = 0;

    if (!out) {
        printf("Cannot create linked output file!\n");
        return;
    }

    global_symbol_count = 0;
    reloc_count = 0;

    for (int i = 0; i < object_count; i++) {
        collect_symbols(objects[i], text_base);
        collect_relocations(objects[i], text_base);
        text_base += get_text_size(objects[i]);
    }

    for (int i = 0; i < object_count; i++) {
        append_text_section(out, objects[i]);
    }

    fclose(out);

    apply_relocations(output_file);
    write_symbol_map("estab.txt");

    printf("Linked output generated: %s\n", output_file);
}

int main() {
    const char *objects[] = {
        "program1.o",
        "program2.o"
    };

    link_multiple_objects("linked.mem", objects, 2);

    return 0;
}
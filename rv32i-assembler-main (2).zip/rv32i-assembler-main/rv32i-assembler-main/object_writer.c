#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "symbol_table.h"

extern Symbol* symbol_table[TABLE_SIZE];

static void trim_newline(char *s) {
    s[strcspn(s, "\r\n")] = 0;
}

static int is_branch_or_jump(const char *mnemonic) {
    return strcmp(mnemonic, "beq") == 0 ||
           strcmp(mnemonic, "bne") == 0 ||
           strcmp(mnemonic, "blt") == 0 ||
           strcmp(mnemonic, "bge") == 0 ||
           strcmp(mnemonic, "jal") == 0;
}

static void write_relocations(FILE *obj, const char *asm_file) {
    FILE *asmf = fopen(asm_file, "r");
    char line[256];
    char current_section[20] = "text";
    unsigned int text_address = 0;

    if (!asmf) {
        printf("Warning: cannot open asm file for relocation records.\n");
        return;
    }

    fprintf(obj, "\n");

    while (fgets(line, sizeof(line), asmf)) {
        trim_newline(line);

        char *p = line;

        while (*p == ' ' || *p == '\t') {
            p++;
        }

        if (p[0] == '\0') continue;

        if (strcmp(p, ".text") == 0) {
            strcpy(current_section, "text");
            continue;
        }

        if (strcmp(p, ".data") == 0) {
            strcpy(current_section, "data");
            continue;
        }

        if (strcmp(current_section, "text") != 0) {
            continue;
        }

        if (strchr(p, ':')) {
            continue;
        }

        if (p[0] == '.') {
            continue;
        }

        char mnemonic[20], op1[30], op2[30], op3[30];
        mnemonic[0] = op1[0] = op2[0] = op3[0] = '\0';

        sscanf(p, "%s %[^,], %[^,], %s", mnemonic, op1, op2, op3);

        if (is_branch_or_jump(mnemonic)) {
            fprintf(obj, "RELOC text %u %s %s\n",
                    text_address,
                    mnemonic,
                    op3);
        }

        text_address += 4;
    }

    fclose(asmf);
}

void write_object_file(const char *filename, const char *asm_file) {
    FILE *obj = fopen(filename, "w");
    FILE *text = fopen("instr.mem", "r");
    FILE *data = fopen("data.mem", "r");

    char line[256];

    if (!obj) {
        printf("Object file could not be created!\n");
        return;
    }

    fprintf(obj, "SECTION .text\n");

    if (text) {
        while (fgets(line, sizeof(line), text)) {
            fprintf(obj, "%s", line);
        }
        fclose(text);
    }

    fprintf(obj, "SECTION .data\n");

    if (data) {
        while (fgets(line, sizeof(line), data)) {
            fprintf(obj, "%s", line);
        }
        fclose(data);
    }

    fprintf(obj, "\n");

    for (int i = 0; i < TABLE_SIZE; i++) {
        Symbol *current = symbol_table[i];

        while (current != NULL) {
            fprintf(obj, "SYMBOL %s GLOBAL %s %u\n",
                    current->label,
                    current->section,
                    current->address);

            current = current->next;
        }
    }

    write_relocations(obj, asm_file);

    fprintf(obj, "END\n");

    fclose(obj);

    printf("Object file generated: %s\n", filename);
}
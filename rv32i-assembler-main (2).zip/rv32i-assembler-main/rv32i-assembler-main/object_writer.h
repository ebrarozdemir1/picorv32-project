#ifndef OBJECT_WRITER_H
#define OBJECT_WRITER_H

void write_object_file(const char *filename, const char *asm_file);

#endif